<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>PrayTimes - Blob - ViewGit</title>
	<link rel="stylesheet" href="default.css" type="text/css" />
	<link rel="icon" type="image/png" href="favicon.png" />
	<link rel="alternate" type="application/rss+xml" title="PrayTimes log" href="?a=rss-log&amp;p=PrayTimes" />
	<meta name="generator" content="ViewGit" />
</head>
<body>


<div class="nav">
<a href=".">Index</a>
 &raquo; <a href="?a=summary&amp;p=PrayTimes">PrayTimes</a> : Blob a7a1c8 / <a href="?a=tree&amp;p=PrayTimes&amp;h=acedbb7357a9bc04eb5bbbd98f33a401f76b8156&amp;hb=1c500fff7f21d1993f205d3e36dc17ee56efdf24&amp;f=v1">v1</a> / <a href="?a=tree&amp;p=PrayTimes&amp;h=82639caea9f60411c2681e3c6ffff234013cb839&amp;hb=1c500fff7f21d1993f205d3e36dc17ee56efdf24&amp;f=v1/php">php</a> / <a href="?a=viewblob&amp;p=PrayTimes&amp;h=a7a1c86ee478e78932ddb25baa07f6c6439ce1f0&amp;hb=1c500fff7f21d1993f205d3e36dc17ee56efdf24&amp;f=v1/php/sample.php">sample.php</a> </div>
<div id="page_body">

<div class="pagenav">
<a href="?a=summary&amp;p=PrayTimes">Summary</a> | <a href="?a=shortlog&amp;p=PrayTimes">Shortlog</a> | <a href="?a=commit&amp;p=PrayTimes&amp;h=1c500fff7f21d1993f205d3e36dc17ee56efdf24">Commit</a> | <a href="?a=commitdiff&amp;p=PrayTimes&amp;h=1c500fff7f21d1993f205d3e36dc17ee56efdf24">Commitdiff</a> | <a href="?a=tree&amp;p=PrayTimes&amp;h=02dc065d16f8664cd5540825a4232f89d6e7a15d&amp;hb=1c500fff7f21d1993f205d3e36dc17ee56efdf24">Tree</a> | 
<form action="?" method="get" class="search">
<input type="hidden" name="a" value="search" />
<input type="hidden" name="p" value="PrayTimes" />
<input type="hidden" name="h" value="1c500fff7f21d1993f205d3e36dc17ee56efdf24" />
<select name="st">
	<option>commit</option>
	<option>change</option>
	<option>author</option>
	<option>committer</option>
</select>
<input type="text" name="s" />
</form>
</div>

<h2>Last commit for v1/php/sample.php: <a href="?a=commit&amp;p=PrayTimes&amp;h=17ee68cff3d814bae3fcf7dc55beaf3e49909889">17ee68cff3d814bae3fcf7dc55beaf3e49909889</a></h2>
<h1>All code licences changed to LGPL v3.0</h1>
<div class="authorinfo">
<a href="?a=search&amp;p=PrayTimes&amp;h=HEAD&amp;st=author&amp;s=Hamid">Hamid</a> [2012-07-05 10:38:10]</div>
<div class="commitmessage">
<pre>
All code licences changed to LGPL v3.0
</pre>
</div>
<div class="file">
<pre>
&lt;?
	// Prayer Time Calculator
	// By: Hamid Zarrabi-Zadeh
	// Inputs : $method, $year, $lat, $lng, $timeZone

	import_request_variables(&quot;gpc&quot;);
	include('PrayTime.php');

	if (!isset($method) || !isset($year) )
		list($method, $year, $lat, $lng, $timeZone) = array(0, 2007, 43, -80, -5);
?&gt;
&lt;html&gt;
&lt;head&gt;
	&lt;title&gt;Prayer Timetable&lt;/title&gt;
&lt;/head&gt;
&lt;style&gt;
	pre {font-family: courier, serif, size: 10pt; margin: 0px 8px;}
&lt;/style&gt;

&lt;body&gt;

&lt;h1&gt; Prayer Timetable &lt;/h1&gt;
&lt;form name=form method=&quot;post&quot; action=&quot;&quot; onSubmit=&quot;submit_form();&quot;&gt;
&lt;div style=&quot;padding:10px; background-color: #F8F7F4; border: 1px dashed #EAE9CD;&quot;&gt;

	Latitude: &lt;input type=&quot;text&quot; value=&quot;&lt;?= $lat ?&gt;&quot; id=&quot;latitude&quot; size=&quot;4&quot;&gt;
	Longitude: &lt;input type=&quot;text&quot; value=&quot;&lt;?= $lng ?&gt;&quot; id=&quot;longitude&quot; size=&quot;4&quot;&gt;
	Time Zone: &lt;input type=&quot;text&quot; value=&quot;&lt;?= $timeZone ?&gt;&quot; id=&quot;timezone&quot; size=&quot;2&quot;&gt;
	Year: &lt;input type=&quot;text&quot; value=&quot;&lt;?= $year ?&gt;&quot; id=&quot;year&quot; size=&quot;4&quot;&gt; &lt;br&gt;
	Method:
	&lt;select id=&quot;method&quot; name=&quot;method&quot; size=&quot;1&quot;&gt;
		&lt;option value=&quot;0&quot;&gt;Shia Ithna-Ashari&lt;/option&gt;
		&lt;option value=&quot;1&quot;&gt;University of Islamic Sciences, Karachi&lt;/option&gt;
		&lt;option value=&quot;2&quot;&gt;Islamic Society of North America (ISNA)&lt;/option&gt;
		&lt;option value=&quot;3&quot;&gt;Muslim World League (MWL)&lt;/option&gt;
		&lt;option value=&quot;4&quot;&gt;Umm al-Qura, Makkah&lt;/option&gt;
		&lt;option value=&quot;5&quot;&gt;Egyptian General Authority of Survey&lt;/option&gt;
		&lt;option value=&quot;7&quot;&gt;Institute of Geophysics, University of Tehran&lt;/option&gt;
    &lt;/select&gt;
	&lt;input type=&quot;submit&quot; value=&quot;Make Timetable&quot; onclick=&quot;submit_form();&quot;&gt;

&lt;/div&gt;
&lt;/form&gt;

&lt;pre&gt;
 Date   Fajr   Sunrise  Dhuhr    Asr   Sunset  Maghrib  Isha
-------------------------------------------------------------
&lt;?

	$prayTime = new PrayTime($method);

	$date = strtotime($year. '-1-1');
	$endDate = strtotime(($year+ 1). '-1-1');

	while ($date &lt; $endDate)
	{
		$times = $prayTime-&gt;getPrayerTimes($date, $lat, $lng, $timeZone);
		$day = date('M d', $date);
		print $day. &quot;\t&quot;. implode(&quot;\t&quot;, $times). &quot;\n&quot;;
		$date += 24* 60* 60;  // next day
	}

?&gt;
&lt;/pre&gt;

&lt;script type=&quot;text/javascript&quot;&gt;

	function submit_form()
	{
		var lat = document.getElementById('latitude').value;
		var lng = document.getElementById('longitude').value;
		var timeZone = document.getElementById('timezone').value;
		var year = document.getElementById('year').value;
		var method = document.getElementById('method').value;
		var table = document.getElementById('timetable');
		var link = '&lt;?= $PHP_SELF ?&gt;'+ '?method='+ method+ '&amp;year='+ year+ '&amp;lat='+ lat+ '&amp;lng='+ lng+ '&amp;timeZone='+ timeZone;
		document.form.action = link;
		document.form.submit();
	}

	document.getElementById('method').selectedIndex = &lt;?= $method ?&gt;;

&lt;/script&gt;

&lt;/body&gt;
&lt;/html&gt;


</pre>
</div>
<div class="ad"><a href="http://viewgit.sourceforge.net/" title="Visit the ViewGit homepage">ViewGit</a></div></div>
</body>
</html>
